library(testthat)
library(ezRun)

test_check("ezRun")
