##' @param doc an object of the class bsdoc to add the <%= object %>.
