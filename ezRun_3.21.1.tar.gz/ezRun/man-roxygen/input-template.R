##' @param input a list, file path or an object of the class EzDataset containing the input.
