##' @param dataset a data.frame from the meta field of an EzDataset.
