##' @param ... additional arguments to be passed to \code{<%= fun %>}.
