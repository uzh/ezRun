##' @param types a character vector containing the types.
