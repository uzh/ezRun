##' @param bamFile a character representing the bam file path.
