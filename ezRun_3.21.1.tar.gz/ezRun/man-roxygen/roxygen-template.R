##' @author Rehrauer, Hubert
##' @author Schmid, Peter
