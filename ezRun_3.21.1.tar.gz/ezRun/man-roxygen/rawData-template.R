##' @param rawData a list of raw data obtained from \code{loadCountDataset()}.
