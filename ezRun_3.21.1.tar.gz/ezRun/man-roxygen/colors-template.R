##' @param colors a character vector containing colors.
