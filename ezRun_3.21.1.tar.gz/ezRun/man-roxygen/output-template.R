##' @param output a list, file path or an object of the class EzDataset containing the output information.
