##' @param con the connection to the file to write in.
