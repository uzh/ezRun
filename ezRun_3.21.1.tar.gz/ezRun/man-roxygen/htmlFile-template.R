##' @param htmlFile a character, ending with .html, representing the file path of an html file.
