##' @param result a list of results.
