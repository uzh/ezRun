## ----library, warning=FALSE,message=FALSE,split=TRUE, message=FALSE, warning=FALSE, results='hide'----
library(ezRun)

## ----conda env, eval=FALSE----------------------------------------------------
# library(ezRun)
# library(reticulate)
# use_condaenv("ezRun", conda = "/usr/local/ngseq/miniconda3/bin/conda",
#              required = TRUE)
# py_discover_config()

## ----humanSetup, echo=TRUE, eval=TRUE-----------------------------------------
organism <- "Homo_sapiens"
db <- "GENCODE"
build <- "GRCh38.p13"
release <- "Release_35"

## ----humanDownload, echo=TRUE, eval=FALSE-------------------------------------
# ## We download the reference genome and gtf from GENCODE release 35
# gtfURL <- "ftp://ftp.ebi.ac.uk/pub/databases/gencode/Gencode_human/release_35/gencode.v35.primary_assembly.annotation.gtf.gz"
# download.file(gtfURL, basename(gtfURL))
# genomeURL <- "ftp://ftp.ebi.ac.uk/pub/databases/gencode/Gencode_human/release_35/GRCh38.primary_assembly.genome.fa.gz"
# download.file(genomeURL, basename(genomeURL))
# featureFn <- basename(gtfURL)
# genomeFn <- basename(genomeURL)

## ----make reference folder, echo=TRUE, eval=FALSE-----------------------------
# refBuild <- file.path(organism, db, build, "Annotation",
#                       str_c(release, "2020-10-30", sep="-"))
# ## The reference folder will be generated under `genomesRoot`, which is current working directory here.
# param <- ezParam(list(refBuild=refBuild, genomesRoot="."))
# buildRefDir(param$ezRef, genomeFile=genomeFn, genesFile=featureFn)
# buildIgvGenome(param$ezRef)

## ----add annotation, echo=TRUE, eval=FALSE------------------------------------
# makeFeatAnnoEnsembl(featureFile=file.path(dirname(param$ezRef@refFeatureFile),
#                                           "features.gtf"),
#                     genomeFile=param$ezRef@refFastaFile,
#                     organism="hsapiens_gene_ensembl")
# 
# makeFeatAnnoEnsembl(featureFile=file.path(dirname(param$ezRef@refFeatureFile),
#                                           "genes.gtf"),
#                     genomeFile=param$ezRef@refFastaFile,
#                     organism="hsapiens_gene_ensembl")

