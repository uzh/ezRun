
## setup your first analysis
ezSetupAnalysis(project=NULL, analysisName="custom-analysis",
                            parentAnalysis=NULL
)
ezPublishAnalysis()

